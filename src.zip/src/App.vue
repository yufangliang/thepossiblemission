<template>
  <v-app id="inspire">
    <v-navigation-drawer
      fixed
      v-model="drawer"
      app
    >
      <v-list dense>
        <v-list-tile @click="routeTo('home','Ninja cats, welcome to the Possible Mission !')">
          <v-list-tile-action>
            <v-icon>home</v-icon>
          </v-list-tile-action>
          <v-list-tile-content>
            <v-list-tile-title class="ch">the Possible Mission</v-list-tile-title>
          </v-list-tile-content>
        </v-list-tile>
        <v-list-tile @click="routeTo('solve','write down a linear equation of two variables(unknown price)')">
          <v-list-tile-action>
            <v-icon>voicemail</v-icon>
          </v-list-tile-action>
          <v-list-tile-content>
            <v-list-tile-title class="ch">Formulation exercise 1 (unknown price)</v-list-tile-title>
          </v-list-tile-content>
        </v-list-tile>
        <v-list-tile @click="routeTo('solve2','write down a linear equation of two variables(unknown amount)')">
          <v-list-tile-action>
            <v-icon>voicemail</v-icon>
          </v-list-tile-action>
          <v-list-tile-content>
            <v-list-tile-title class="ch">Formulation exercise 2 (unknown ampunt)</v-list-tile-title>
          </v-list-tile-content>
        </v-list-tile>
        <v-list-tile @click="routeTo('graph','graph of linear equation')">
          <v-list-tile-action>
            <v-icon>show_chart</v-icon>
          </v-list-tile-action>
          <v-list-tile-content>
            <v-list-tile-title class="ch">Diagramming exercise</v-list-tile-title>
          </v-list-tile-content>
        </v-list-tile>
        <!-- 
        <v-list-tile @click="routeTo('coordinate','coordinate plane')">
          <v-list-tile-action>
            <v-icon>show_chart</v-icon>
          </v-list-tile-action>
          <v-list-tile-content>
            <v-list-tile-title class="ch">Coordinate board</v-list-tile-title>
          </v-list-tile-content>
        </v-list-tile>
        -->
      </v-list>
    </v-navigation-drawer>
    <v-toolbar color="indigo" dark fixed app>
      <v-toolbar-side-icon @click.stop="drawer = !drawer"></v-toolbar-side-icon>
      <v-toolbar-title class="ch">{{ currentTitle }}</v-toolbar-title>
    </v-toolbar>
    <v-content>
      <v-container fluid fill-height>
        <v-layout
          justify-center
          align-center
        >
          <vue-home v-if="currentShow === 'home'"></vue-home>
          <vue-graph v-else-if="currentShow === 'graph'"></vue-graph>
          <vue-solve v-else-if="currentShow ==='solve'"></vue-solve>
          <vue-solve2 v-else-if="currentShow ==='solve2'"></vue-solve2>
          <vue-coordinate v-else-if="currentShow ==='coordinate'"></vue-coordinate>
        </v-layout>
      </v-container>
    </v-content>
    <v-footer color="indigo" app>
      <span class="white--text">&copy; 2017</span>
    </v-footer>
  </v-app>
</template>

<script>
import Home from './components/Home.vue'
import Graph from './components/Graph.vue'
import Solve from './components/Solve.vue'
import Solve2 from './components/Solve2.vue'
import Coordinate from './components/Coordinate.vue'

export default {
  components: {
    'vue-home': Home,
    'vue-graph': Graph,
    'vue-solve': Solve,
    'vue-solve2': Solve2,
    'vue-coordinate': Coordinate
  },
  data () {
    return {
      currentShow: 'home',
      currentTitle: 'Main page',
      drawer: null,
    }
  },
  props: {
    source: String
  },
  methods: {
    routeTo: function(target, title) {
      this.currentShow = target
      this.currentTitle = title
    }
  }
}
</script>
<style>
.ch{
  font-family: Microsoft JhengHei;
}
</style>
