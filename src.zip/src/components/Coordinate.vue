<template>
  <div>
    <v-btn color="success" v-on:click="point">Point</v-btn>
    <div id="coordinate">
    </div>
  </div>
</template>

<script>
import * as d3 from 'd3'
import functionPlot from 'function-plot'

export default {
  mounted: () => {
    functionPlot({
      target: '#coordinate',
      grid: true,
      data: [{
        fn: ''
      }]
    })
  },
  methods: {
    point: function(){

    }
  }
}
</script>

<style>
.top-right-legend {
  font-size: 2em
}
:text p{
  font-size: 2em
}
</style>