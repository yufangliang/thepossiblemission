<template>
  <div>
    <v-container grid-list-md text-xs-center>
      <v-layout row>
        <v-flex xs12 md10 offset-md1>
          <div id="quadratic-with-options"></div>
        </v-flex>
        <v-flex xs12 md10 offset-md1>
          <v-form v-model="valid" ref="form" lazy-validation>
            <v-text-field
              label="equation_1"
              v-model="equation_1"
              :rules="equation_Rules"
              :counter="10"
              required
            ></v-text-field>
            <v-text-field
              label="equation_2"
              v-model="equation_2"
              :rules="equation_Rules"
              required
            ></v-text-field>
            <v-btn @click="submit" color="primary">
              submit
            </v-btn>
            <v-btn @click="clear" color="error">
              clear
            </v-btn>
          </v-form>
        </v-flex>
      </v-layout>
    </v-container>
  </div>
</template>

<script>
import * as d3 from 'd3'
import functionPlot from 'function-plot'

export default {
  data: () => ({
    valid: true,
    equation_1: '',
    equation_2: '',
    equation_Rules: [
      (v) => !!v || 'Equation is required',
    ],
    current_x: '',
    current_y: '',
    select: null,
    checkbox: false
  }),
  methods: {
    submit() {
      var instance = functionPlot({
        title: ' ',
        target: '#quadratic-with-options',
        width: 800,
        height: 800,
        grid: true,
        xAxis: {
          domain: [-7, 7]
        },
        yAxis: {
          domain: [-7, 7]
        },
        tip: {
          xLine: true,    // dashed line parallel to y = 0
          yLine: true,    // dashed line parallel to x = 0
          renderer: function (x, y, index) {
            // the returning value will be shown in the tip
            return 'X:'+x.toFixed(1)+' Y:'+y.toFixed(1)
          }
        },
        data: [
          { fn: this.equation_1 },
          { fn: this.equation_2 }
        ]
      })
      this.showEquation = true
      // this.graph.on([tip])
    },
    clear() {
      location.reload()
    }
  }
}
</script>

<style>
.top-right-legend {
  display: none;
}
text{
  font-size: 2em
}
</style>
