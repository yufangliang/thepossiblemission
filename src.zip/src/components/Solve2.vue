<template>
  <v-layout column>
    <v-flex xs12 sm6 offset-sm3>
      <v-card>
        <v-card-media src="http://www.demo.cccul.com/wp-content/uploads/2017/10/MISSION.png" height="150px">
        </v-card-media>
        <v-card-title primary-title>
          <div>
            <h3 class="headline mb-0 ch">Now, for each biscuit and cake costs $20 and $150 separately. Let's enter this round! </h3>
          </div>
        </v-card-title>
        <v-card-actions>
          <v-btn color="error" class="ch" v-on:click="start">Go</v-btn>
        </v-card-actions>
      </v-card>
    </v-flex>
    <v-flex xs12 sm6 offset-sm3 v-show="preview">
      <v-card>
        <v-container fluid grid-list-md>
          <v-layout row wrap>
            <v-flex
              v-bind="{ [`xs${card.flex}`]: true }"
              v-for="card in cards"
              :key="card.cardID"
            >
              <v-card>
                <v-card-media
                  :src="card.src"
                  height="200px"
                >
                  <v-container fill-height fluid>
                    <v-layout fill-height>
                    </v-layout>
                  </v-container>
                </v-card-media>
                <v-card-actions>
                  <v-spacer v-if="convert_status==0" class="display-1 black--text ch">number：{{ card.number }}</v-spacer>
                  <v-spacer v-if="convert_status==1" class="display-1 red--text ch">number：{{ card.number }}</v-spacer>
                </v-card-actions>
              </v-card>
            </v-flex>
          </v-layout>
        </v-container>
      </v-card>
    </v-flex>
    <v-flex xs12 sm6 offset-sm3 v-show="preview">
      <v-card>
        <v-card-media src="https://optinmonster.com/wp-content/uploads/2016/03/Reduce-Shopping-Cart-Abandonment.png" height="150px">
        </v-card-media>
        <v-card-title primary-title>
          <div>
            <p class="display-1 ch">
              Total：{{ cards[0].price }}
              {{ symbol }}
              <v-tooltip bottom>
              <span class="red--text" slot="activator">
              {{ cards[0].number }}
              </span>
              <span class="ch headline">number of biscuit</span>
              </v-tooltip>
              +{{ cards[1].price }}
              {{ symbol }}
              <v-tooltip bottom>
              <span class="red--text" slot="activator">
              {{ cards[1].number }}
              </span>
              <span class="ch headline">number of cake</span>
              </v-tooltip>
            </p>
          </div>
        </v-card-title>
        <v-card-actions>
          <v-btn v-on:click="convert"  color="success" large class="ch">switch</v-btn>
          <v-btn v-on:click="reset"  color="info" large class="ch">discard</v-btn>
        </v-card-actions>
      </v-card>
    </v-flex>
  </v-layout>
</template>

<script>
  export default {
    data: () => ({
      preview: false,
      detail: false,
      confirm: true,
      symbol: '',
      edit_mode: false,
      convert_status: 1,
      cards: [
        { cardID: 0, title: 'biscuit', price: 20, src: 'https://images-gmi-pmc.edge-generalmills.com/e8198dd2-770b-4c7c-a748-ca7538cf48d0.jpg', flex: 6, number: 'X' },
        { cardID: 1, title: 'cake', price: 150, src: 'http://homecookingadventure.com/images/recipes/Chocolate_Mirror_Cake_main.jpg', flex: 6, number: 'Y' }
      ]
    }),
    methods: {
      start: function(){
        this.preview = true
      },
      add: function(id){
        this.cards[id].number += 1;
      },
      reduce: function(id){
        this.cards[id].number -= 1;
      },
      edit: function(id){
        console.log(id);

        if(this.edit_mode){
          this.edit_mode = false;
        }
        else{
          this.edit_mode = true;
        }
      },
      submit: function(){
        this.detail = true;
        this.confirm = false;
        this.preview = false;
      },
      convert: function(){
        if(this.convert_status == 0){
          this.cards[0].number = 'X';
          this.cards[1].number = 'Y';
          this.symbol = ''
          this.convert_status = 1;
        }
        else{
          this.cards[0].number = 6;
          this.cards[1].number = 2;
          this.symbol = 'x';
          this.convert_status = 0;
        }
      },
      reset: function(){
        this.preview = true;
        this.detail = false;
        this.confirm = true;
        this.cards[0].number = 0;
        this.cards[1].number = 0;
      }
    }
  }
</script>

<style>
.bold{
  font-weight: bold;
}
</style>
